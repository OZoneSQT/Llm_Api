[CmdletBinding()]
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Args
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script = Join-Path $PSScriptRoot 'text_online.py'
& (Join-Path $PSScriptRoot 'run_in_acaonda.ps1') -Script $script -ScriptArgs $Args
